﻿namespace test
{
    partial class AlbumForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AlbumForm));
            this.layeredListBox1 = new LayeredSkin.Controls.LayeredListBox();
            this.layeredButton1 = new LayeredSkin.Controls.LayeredButton();
            this.layeredButton2 = new LayeredSkin.Controls.LayeredButton();
            this.layeredButton3 = new LayeredSkin.Controls.LayeredButton();
            this.SuspendLayout();
            // 
            // layeredListBox1
            // 
            this.layeredListBox1.AutoFocus = false;
            this.layeredListBox1.BackColor = System.Drawing.Color.Transparent;
            this.layeredListBox1.Borders.BottomColor = System.Drawing.Color.Black;
            this.layeredListBox1.Borders.BottomWidth = 1;
            this.layeredListBox1.Borders.LeftColor = System.Drawing.Color.Black;
            this.layeredListBox1.Borders.LeftWidth = 1;
            this.layeredListBox1.Borders.RightColor = System.Drawing.Color.Black;
            this.layeredListBox1.Borders.RightWidth = 1;
            this.layeredListBox1.Borders.TopColor = System.Drawing.Color.Black;
            this.layeredListBox1.Borders.TopWidth = 1;
            this.layeredListBox1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredListBox1.Canvas")));
            this.layeredListBox1.EnabledMouseWheel = true;
            this.layeredListBox1.ItemSize = new System.Drawing.Size(100, 100);
            this.layeredListBox1.ListTop = 0;
            this.layeredListBox1.Location = new System.Drawing.Point(82, 48);
            this.layeredListBox1.Name = "layeredListBox1";
            this.layeredListBox1.Orientation = LayeredSkin.Controls.ListOrientation.Horizontal;
            this.layeredListBox1.RollSize = 20;
            this.layeredListBox1.ScrollBarBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.layeredListBox1.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.layeredListBox1.ScrollBarHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.layeredListBox1.ScrollBarWidth = 10;
            this.layeredListBox1.ShowScrollBar = true;
            this.layeredListBox1.Size = new System.Drawing.Size(413, 150);
            this.layeredListBox1.SmoothScroll = true;
            this.layeredListBox1.TabIndex = 0;
            this.layeredListBox1.Text = "layeredListBox1";
            this.layeredListBox1.Ulmul = false;
            this.layeredListBox1.Value = 0D;
            this.layeredListBox1.ItemClick += new System.EventHandler<LayeredSkin.Controls.ItemClickEventArgs>(this.layeredListBox1_ItemClick);
            // 
            // layeredButton1
            // 
            this.layeredButton1.AdaptImage = true;
            this.layeredButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton1.BaseColor = System.Drawing.Color.Wheat;
            this.layeredButton1.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.BottomWidth = 1;
            this.layeredButton1.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.LeftWidth = 1;
            this.layeredButton1.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.RightWidth = 1;
            this.layeredButton1.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.TopWidth = 1;
            this.layeredButton1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton1.Canvas")));
            this.layeredButton1.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton1.HaloColor = System.Drawing.Color.White;
            this.layeredButton1.HaloSize = 5;
            this.layeredButton1.HoverImage = null;
            this.layeredButton1.IsPureColor = false;
            this.layeredButton1.Location = new System.Drawing.Point(16, 97);
            this.layeredButton1.Name = "layeredButton1";
            this.layeredButton1.NormalImage = null;
            this.layeredButton1.PressedImage = null;
            this.layeredButton1.Radius = 10;
            this.layeredButton1.ShowBorder = true;
            this.layeredButton1.Size = new System.Drawing.Size(48, 48);
            this.layeredButton1.TabIndex = 1;
            this.layeredButton1.Text = "<<";
            this.layeredButton1.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredButton1.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.layeredButton1.Click += new System.EventHandler(this.layeredButton1_Click);
            // 
            // layeredButton2
            // 
            this.layeredButton2.AdaptImage = true;
            this.layeredButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton2.BaseColor = System.Drawing.Color.Wheat;
            this.layeredButton2.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.BottomWidth = 1;
            this.layeredButton2.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.LeftWidth = 1;
            this.layeredButton2.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.RightWidth = 1;
            this.layeredButton2.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.TopWidth = 1;
            this.layeredButton2.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton2.Canvas")));
            this.layeredButton2.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton2.HaloColor = System.Drawing.Color.White;
            this.layeredButton2.HaloSize = 5;
            this.layeredButton2.HoverImage = null;
            this.layeredButton2.IsPureColor = false;
            this.layeredButton2.Location = new System.Drawing.Point(516, 96);
            this.layeredButton2.Name = "layeredButton2";
            this.layeredButton2.NormalImage = null;
            this.layeredButton2.PressedImage = null;
            this.layeredButton2.Radius = 10;
            this.layeredButton2.ShowBorder = true;
            this.layeredButton2.Size = new System.Drawing.Size(50, 49);
            this.layeredButton2.TabIndex = 2;
            this.layeredButton2.Text = ">>";
            this.layeredButton2.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton2.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredButton2.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.layeredButton2.Click += new System.EventHandler(this.layeredButton2_Click);
            // 
            // layeredButton3
            // 
            this.layeredButton3.AdaptImage = true;
            this.layeredButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.layeredButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton3.BaseColor = System.Drawing.Color.Transparent;
            this.layeredButton3.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton3.Borders.BottomWidth = 1;
            this.layeredButton3.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton3.Borders.LeftWidth = 1;
            this.layeredButton3.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton3.Borders.RightWidth = 1;
            this.layeredButton3.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton3.Borders.TopWidth = 1;
            this.layeredButton3.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton3.Canvas")));
            this.layeredButton3.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton3.HaloColor = System.Drawing.Color.White;
            this.layeredButton3.HaloSize = 5;
            this.layeredButton3.HoverImage = ((System.Drawing.Image)(resources.GetObject("layeredButton3.HoverImage")));
            this.layeredButton3.IsPureColor = false;
            this.layeredButton3.Location = new System.Drawing.Point(539, -1);
            this.layeredButton3.Name = "layeredButton3";
            this.layeredButton3.NormalImage = ((System.Drawing.Image)(resources.GetObject("layeredButton3.NormalImage")));
            this.layeredButton3.PressedImage = ((System.Drawing.Image)(resources.GetObject("layeredButton3.PressedImage")));
            this.layeredButton3.Radius = 10;
            this.layeredButton3.ShowBorder = true;
            this.layeredButton3.Size = new System.Drawing.Size(39, 20);
            this.layeredButton3.TabIndex = 3;
            this.layeredButton3.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton3.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredButton3.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.layeredButton3.Click += new System.EventHandler(this.layeredButton3_Click);
            // 
            // AlbumForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.ClientSize = new System.Drawing.Size(578, 219);
            this.Controls.Add(this.layeredButton3);
            this.Controls.Add(this.layeredButton2);
            this.Controls.Add(this.layeredButton1);
            this.Controls.Add(this.layeredListBox1);
            this.Name = "AlbumForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AlbumForm";
            this.Load += new System.EventHandler(this.AlbumForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private LayeredSkin.Controls.LayeredListBox layeredListBox1;
        private LayeredSkin.Controls.LayeredButton layeredButton1;
        private LayeredSkin.Controls.LayeredButton layeredButton2;
        private LayeredSkin.Controls.LayeredButton layeredButton3;
    }
}