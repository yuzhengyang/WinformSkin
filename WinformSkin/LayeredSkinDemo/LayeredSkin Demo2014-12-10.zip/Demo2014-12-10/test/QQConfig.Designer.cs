﻿namespace test
{
    partial class QQConfig
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QQConfig));
            this.layeredPictureBox2 = new LayeredSkin.Controls.LayeredPictureBox();
            this.layeredButton2 = new LayeredSkin.Controls.LayeredButton();
            this.layeredButton1 = new LayeredSkin.Controls.LayeredButton();
            this.layeredPictureBox1 = new LayeredSkin.Controls.LayeredPictureBox();
            this.layeredButton3 = new LayeredSkin.Controls.LayeredButton();
            this.SuspendLayout();
            // 
            // layeredPictureBox2
            // 
            this.layeredPictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredPictureBox2.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredPictureBox2.Borders.BottomWidth = 1;
            this.layeredPictureBox2.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredPictureBox2.Borders.LeftWidth = 1;
            this.layeredPictureBox2.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredPictureBox2.Borders.RightWidth = 1;
            this.layeredPictureBox2.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredPictureBox2.Borders.TopWidth = 1;
            this.layeredPictureBox2.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredPictureBox2.Canvas")));
            this.layeredPictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("layeredPictureBox2.Image")));
            this.layeredPictureBox2.Images = new System.Drawing.Image[] {
        ((System.Drawing.Image)(((System.Drawing.Image)(resources.GetObject("layeredPictureBox2.Images")))))};
            this.layeredPictureBox2.Interval = 100;
            this.layeredPictureBox2.Location = new System.Drawing.Point(12, 30);
            this.layeredPictureBox2.MultiImageAnimation = false;
            this.layeredPictureBox2.Name = "layeredPictureBox2";
            this.layeredPictureBox2.Size = new System.Drawing.Size(338, 82);
            this.layeredPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.layeredPictureBox2.TabIndex = 2;
            this.layeredPictureBox2.Text = "layeredPictureBox2";
            // 
            // layeredButton2
            // 
            this.layeredButton2.AdaptImage = true;
            this.layeredButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton2.BaseColor = System.Drawing.Color.Wheat;
            this.layeredButton2.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.BottomWidth = 1;
            this.layeredButton2.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.LeftWidth = 1;
            this.layeredButton2.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.RightWidth = 1;
            this.layeredButton2.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton2.Borders.TopWidth = 1;
            this.layeredButton2.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton2.Canvas")));
            this.layeredButton2.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton2.HaloColor = System.Drawing.Color.White;
            this.layeredButton2.HaloSize = 5;
            this.layeredButton2.HoverImage = ((System.Drawing.Image)(resources.GetObject("layeredButton2.HoverImage")));
            this.layeredButton2.IsPureColor = false;
            this.layeredButton2.Location = new System.Drawing.Point(335, 81);
            this.layeredButton2.Name = "layeredButton2";
            this.layeredButton2.NormalImage = ((System.Drawing.Image)(resources.GetObject("layeredButton2.NormalImage")));
            this.layeredButton2.PressedImage = null;
            this.layeredButton2.Radius = 10;
            this.layeredButton2.ShowBorder = true;
            this.layeredButton2.Size = new System.Drawing.Size(22, 22);
            this.layeredButton2.TabIndex = 3;
            this.layeredButton2.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton2.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredButton2.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.layeredButton2.Click += new System.EventHandler(this.layeredButton2_Click);
            // 
            // layeredButton1
            // 
            this.layeredButton1.AdaptImage = true;
            this.layeredButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton1.BaseColor = System.Drawing.Color.Wheat;
            this.layeredButton1.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.BottomWidth = 1;
            this.layeredButton1.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.LeftWidth = 1;
            this.layeredButton1.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.RightWidth = 1;
            this.layeredButton1.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton1.Borders.TopWidth = 1;
            this.layeredButton1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton1.Canvas")));
            this.layeredButton1.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton1.HaloColor = System.Drawing.Color.White;
            this.layeredButton1.HaloSize = 5;
            this.layeredButton1.HoverImage = ((System.Drawing.Image)(resources.GetObject("layeredButton1.HoverImage")));
            this.layeredButton1.IsPureColor = false;
            this.layeredButton1.Location = new System.Drawing.Point(307, 81);
            this.layeredButton1.Name = "layeredButton1";
            this.layeredButton1.NormalImage = ((System.Drawing.Image)(resources.GetObject("layeredButton1.NormalImage")));
            this.layeredButton1.PressedImage = null;
            this.layeredButton1.Radius = 10;
            this.layeredButton1.ShowBorder = true;
            this.layeredButton1.Size = new System.Drawing.Size(22, 22);
            this.layeredButton1.TabIndex = 4;
            this.layeredButton1.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.layeredButton1.TextShowMode = LayeredSkin.TextShowModes.Halo;
            this.layeredButton1.Click += new System.EventHandler(this.layeredButton1_Click);
            // 
            // layeredPictureBox1
            // 
            this.layeredPictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredPictureBox1.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredPictureBox1.Borders.BottomWidth = 1;
            this.layeredPictureBox1.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredPictureBox1.Borders.LeftWidth = 1;
            this.layeredPictureBox1.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredPictureBox1.Borders.RightWidth = 1;
            this.layeredPictureBox1.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredPictureBox1.Borders.TopWidth = 1;
            this.layeredPictureBox1.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredPictureBox1.Canvas")));
            this.layeredPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("layeredPictureBox1.Image")));
            this.layeredPictureBox1.Images = new System.Drawing.Image[] {
        ((System.Drawing.Image)(((System.Drawing.Image)(resources.GetObject("layeredPictureBox1.Images")))))};
            this.layeredPictureBox1.Interval = 100;
            this.layeredPictureBox1.Location = new System.Drawing.Point(132, 136);
            this.layeredPictureBox1.MultiImageAnimation = false;
            this.layeredPictureBox1.Name = "layeredPictureBox1";
            this.layeredPictureBox1.Size = new System.Drawing.Size(100, 76);
            this.layeredPictureBox1.TabIndex = 5;
            this.layeredPictureBox1.Text = "layeredPictureBox1";
            // 
            // layeredButton3
            // 
            this.layeredButton3.AdaptImage = true;
            this.layeredButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.layeredButton3.BaseColor = System.Drawing.Color.White;
            this.layeredButton3.Borders.BottomColor = System.Drawing.Color.Empty;
            this.layeredButton3.Borders.BottomWidth = 1;
            this.layeredButton3.Borders.LeftColor = System.Drawing.Color.Empty;
            this.layeredButton3.Borders.LeftWidth = 1;
            this.layeredButton3.Borders.RightColor = System.Drawing.Color.Empty;
            this.layeredButton3.Borders.RightWidth = 1;
            this.layeredButton3.Borders.TopColor = System.Drawing.Color.Empty;
            this.layeredButton3.Borders.TopWidth = 1;
            this.layeredButton3.Canvas = ((System.Drawing.Bitmap)(resources.GetObject("layeredButton3.Canvas")));
            this.layeredButton3.ControlState = LayeredSkin.Controls.ControlStates.Normal;
            this.layeredButton3.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.layeredButton3.HaloColor = System.Drawing.Color.White;
            this.layeredButton3.HaloSize = 5;
            this.layeredButton3.HoverImage = null;
            this.layeredButton3.IsPureColor = false;
            this.layeredButton3.Location = new System.Drawing.Point(136, 235);
            this.layeredButton3.Name = "layeredButton3";
            this.layeredButton3.NormalImage = null;
            this.layeredButton3.PressedImage = null;
            this.layeredButton3.Radius = 10;
            this.layeredButton3.ShowBorder = true;
            this.layeredButton3.Size = new System.Drawing.Size(96, 39);
            this.layeredButton3.TabIndex = 6;
            this.layeredButton3.Text = "返回";
            this.layeredButton3.TextLocationOffset = new System.Drawing.Point(0, 0);
            this.layeredButton3.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            this.layeredButton3.TextShowMode = LayeredSkin.TextShowModes.Ordinary;
            this.layeredButton3.Click += new System.EventHandler(this.layeredButton3_Click);
            // 
            // QQConfig
            // 
            this.AnimationType = LayeredSkin.Forms.AnimationTypes.ThreeDTurn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.CaptionShowMode = LayeredSkin.TextShowModes.None;
            this.ClientSize = new System.Drawing.Size(369, 343);
            this.Controls.Add(this.layeredButton3);
            this.Controls.Add(this.layeredPictureBox1);
            this.Controls.Add(this.layeredButton2);
            this.Controls.Add(this.layeredButton1);
            this.Controls.Add(this.layeredPictureBox2);
            this.DrawIcon = false;
            this.Name = "QQConfig";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "QQConfig";
            this.Load += new System.EventHandler(this.QQConfig_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private LayeredSkin.Controls.LayeredPictureBox layeredPictureBox2;
        private LayeredSkin.Controls.LayeredButton layeredButton2;
        private LayeredSkin.Controls.LayeredButton layeredButton1;
        private LayeredSkin.Controls.LayeredPictureBox layeredPictureBox1;
        private LayeredSkin.Controls.LayeredButton layeredButton3;
    }
}